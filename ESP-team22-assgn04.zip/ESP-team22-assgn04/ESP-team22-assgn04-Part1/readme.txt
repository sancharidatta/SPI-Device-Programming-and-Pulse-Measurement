Team no :22
Team Members :
1. Bhavana Santhoshi Siga - 1214945459
2. Sanchari Datta - 1215306118


Files :
Source code   : assgn4.c
Makefile      : Makefile

Prerequisites:
Linux kernel (preferably linux 2.6.19 and above) GNU (preferably gcc 4.5.0 and above)

Galileo Set up : The Boot Image is flashed into an SD card and inserted into the Board. A Static IP address is set to the board and a connection is established between the host machine and Galileo. Then the toolchain SDK is downloaded and extracted into a directory on your host machine.

Connection between host and Galileo : We can either use the shell screen to establish communication between the host machine and the Galileo or use Putty. Find the ip address of the  ethernet connection and the Galileo, which can be set according to us by using the command
"ifconfig  enp0s20f6 192.168.1.5  netmask  255.255.0.0  up"

The SDK is extracted to the directory : "/opt/iot-devkit/1.7.2/sysroots"

The code is edited,compiled and run using GCC compiler using the commands gedit(editing), gcc(compiling), ./a.out(running).

Installing GCC compiler :

"sudo apt-get install gcc" - this would install gcc compiler on hostmachine

Type "make" for compiling the code.

The code can be found in assgn4.c wherein the code lines are commented to give a description of the functions used.

After setting up the Galileo Board,copy the code from host machine to the board : "scp assgn4 root@192.168.1.5:/home"

Open the shell terminal and navigate to "home" directory and execute: "./assgn4"

We can see 4 emoji patterns changing with distance from ultrasonic sensor.










